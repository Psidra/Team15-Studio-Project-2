#include "SceneManager.h"
#include "Application.h"
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <stdio.h>
#include <stdlib.h>

void SceneManager::AddScene(Scene *scene)
{

}

void SceneManager::SetNextScene(int sceneID)
{

}

void SceneManager::Update()
{
	//if (IsKeyPressed(VK_F1) && (scene != scene1))
	//{
	//	scene->Exit();
	//	scene = scene1;
	//	scene->Init();
	//}
	//else if (IsKeyPressed(VK_F2) && (scene != scene2))
	//{
	//	scene->Exit();
	//	scene = scene2;
	//	scene->Init();
	//}

	//scene->Update(m_timer.getElapsedTime());
	//scene->Render();
	////Swap buffers
	//glfwSwapBuffers(m_window);
	////Get and organize events, like keyboard and mouse input, window resizing, etc...
	//glfwPollEvents();
	//m_timer.waitUntil(frameTime);       // Frame rate limiter. Limits each frame to a specified time in ms.
}